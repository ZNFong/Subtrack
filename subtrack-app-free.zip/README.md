# Getting SubTrack live on the internet — a beginner's guide

You don't need to know how to code. You just need to follow these steps in
order, like a recipe. It'll take maybe 20–30 minutes the first time.

I'll explain what each thing is before asking you to use it.

---

## What you have right now

A folder of files (this project) that makes up your website. Right now it
only exists on your computer / in this chat — nobody else can see it. These
next steps put it on the actual internet with a real address, like
`subtrack-yourname.vercel.app`.

---

## Step 1 — Download this project to your computer

1. Find the **download** option for this file (it should be a `.zip` file —
   ask me to zip it if you only see separate files)
2. Save it somewhere easy to find, like your Desktop
3. Double-click the `.zip` file to "unzip" it — this turns it into a regular
   folder you can open

You should end up with a folder containing things like `package.json`,
a `src` folder, an `api` folder, etc.

---

## Step 2 — Create a GitHub account

**What GitHub is:** think of it like Google Drive, but specifically for
storing code projects. The next service we use (Vercel) plugs directly into
it — that's the only reason we need it.

1. Go to **github.com**
2. Click **Sign up**
3. Enter your email, make a password, pick a username
4. Verify your email if it asks

That's it — free account, no payment info needed.

---

## Step 3 — Upload your project to GitHub

1. Once logged in, go to **github.com/new**
2. Under "Repository name," type `subtrack-app`
3. Leave everything else as default
4. Click the green **Create repository** button
5. On the next page, look for a link that says **"uploading an existing
   file"** — click it
6. Open the folder you unzipped in Step 1, select **everything inside it**
   (all files and folders — `package.json`, `src`, `api`, `public`,
   `index.html`, `vercel.json`, `vite.config.js`) and drag them all into the
   browser window
7. Scroll down, click the green **Commit changes** button

Your code is now on GitHub. You'll never need to look at it directly again
unless you want to make changes later.

---

## Step 4 — Get your Anthropic API key

**What this is:** the key that lets your website talk to Claude (the AI) to
read pasted subscription emails. Think of it like a password just for your
app to use the AI — it's different from your claude.ai login.

1. Go to **console.anthropic.com**
2. Sign up or log in
3. On the left sidebar, click **API Keys**
4. Click **Create Key**
5. Give it any name (e.g. "subtrack")
6. **Copy the key immediately** and paste it into a notes app — you can't
   view it again later, you'd have to make a new one

This uses pay-as-you-go credit (separate from any Claude subscription you
have). For a small personal app, this typically costs just cents to a few
dollars a month.

---

## Step 5 — Deploy your site with Vercel

**What Vercel is:** the service that takes your code from GitHub and turns
it into an actual live website with a real address, for free.

1. Go to **vercel.com**
2. Click **Sign Up**, then choose **Continue with GitHub** (this links the
   two accounts — you'll click "Authorize" on a GitHub popup)
3. Once logged in, click **Add New** → **Project**
4. You'll see a list of your GitHub repositories — find **subtrack-app** and
   click **Import** next to it
5. Before clicking the deploy button, look for a section called
   **Environment Variables**. Click to expand it, then:
   - In the first box (Name), type: `ANTHROPIC_API_KEY`
   - In the second box (Value), paste the key you copied in Step 4
   - Click **Add**
6. Now click the big **Deploy** button

Wait about 60 seconds. A little confetti animation usually means it worked.
You'll be given a link like `subtrack-app-yourname.vercel.app` — **that's
your real, live website.** Click it.

---

## Step 6 — Put it on your phone like an app

1. Open your new website link on your phone
2. **On iPhone:** tap the **Share** icon (square with an arrow) → scroll
   down → **Add to Home Screen**
3. **On Android:** tap the **⋮** (three dots) menu → **Add to Home Screen**
   or **Install app**

It now sits on your home screen with its own icon. Opening it looks and
feels exactly like a normal app — full screen, no browser bar.

---

## If something goes wrong

- **Deploy failed / red error on Vercel:** double check every file from the
  unzipped folder got uploaded to GitHub in Step 3 — it's easy to miss the
  hidden `api` folder
- **AI parsing doesn't work on the live site:** double-check the
  `ANTHROPIC_API_KEY` was typed exactly right in Step 5 (no extra spaces)
- **Anything else:** copy the exact error message and send it to me — I can
  tell you exactly what's wrong

---

## What this version can and can't do (be aware)

**Can:**
- Be used by anyone who visits the link
- Save each visitor's own subscriptions in their own browser
- Use real AI to read pasted confirmation emails

**Can't yet:**
- Sync your data across multiple devices (it's saved to one browser, not a
  shared account)
- Send you push notifications about renewals (browsers can't reliably do
  this — that needs a real native app, down the road if this takes off)

If you want real accounts and synced data later, tell me and I'll add that
next — it just means adding one more free service (a database).

---

## Making changes later

Anytime you want to tweak something:
1. Ask me to make the change and give you the updated file(s)
2. Go to your repository on GitHub, open the file that changed, click the
   pencil (edit) icon, replace the content, click **Commit changes**
3. Vercel automatically updates your live site within about 30 seconds —
   nothing else to do
